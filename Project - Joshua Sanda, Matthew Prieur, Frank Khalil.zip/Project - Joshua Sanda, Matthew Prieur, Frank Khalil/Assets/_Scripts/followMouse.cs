﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class followMouse : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Cursor.lockState = CursorLockMode.Confined;
        Cursor.visible = false;
        transform.position = Input.mousePosition;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        transform.position = Input.mousePosition;
    }
}
