﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet556 : MonoBehaviour {

    Rigidbody rb;
    public int damage;
    public bullet556(int d) {
        damage = d;
    }

    void Start() {
        Invoke("TimedDestroy", 1f);
        rb = GetComponent<Rigidbody>();
        rb.velocity = GetComponentInParent<Transform>().up * 100f;
    }

    private void OnCollisionEnter(Collision collision) {
        if(collision.collider.tag == "Enemy"){
            Debug.Log("Collision with Enemy!");
            gameObject.GetComponent<MeshRenderer>().enabled = false;
            collision.gameObject.GetComponent<Enemy>().health -= damage;
        }
    }

    private void TimedDestroy() {
        Destroy(gameObject);
    }
}