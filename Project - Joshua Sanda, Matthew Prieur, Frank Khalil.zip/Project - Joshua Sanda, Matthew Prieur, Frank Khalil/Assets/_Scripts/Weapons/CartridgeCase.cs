﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CartridgeCase : MonoBehaviour
{
    Rigidbody rb;

    private void Start() {
        rb = GetComponent<Rigidbody>();
        rb.AddForce(Vector3.back * 4f, ForceMode.Impulse);
    }
    private void OnCollisionEnter(Collision collision) {
        Invoke("DestroyBullet", 1f);
    }

    public void DestroyBullet() {
        Destroy(gameObject);
    }
}
