﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : MonoBehaviour
{

    public GameObject bullet;
    public GameObject shellCasing;
    public GameObject EjectionPort;
    public GameObject barrel;
    public GameObject go;
    public int TotalAmmo = 180;
    public int MagAmmo= 30;
    public int damage = 10;
    public int GunMagCapacity;
    public int range = 50;

    // Update is called once per frame
    void Update()
    {
        if(Input.GetMouseButtonDown(0)) {
            if(MagAmmo > 0)
                Shoot();
        }
        if(MagAmmo != 30 && Input.GetKey(KeyCode.R)) {
            reload();
        }
    }

    private void Shoot() {
        bullet.GetComponent<bullet556>().damage = damage;
        Instantiate(bullet, barrel.transform.position, barrel.transform.rotation);       
        Instantiate(shellCasing, EjectionPort.transform.position, shellCasing.transform.rotation);
        MagAmmo -= 1;
    }

    public void reload() {
        if(MagAmmo < GunMagCapacity && TotalAmmo > 0) {  //if less than full mag, reload.
            int temp = GunMagCapacity - MagAmmo; // get the difference... the ammo needed to fill the magazine.
            if(TotalAmmo > temp) {      //if ammo needed is not greater than whats left
                TotalAmmo -= temp;      //
                MagAmmo += temp;
            }
            else {
                MagAmmo += TotalAmmo;
                TotalAmmo = 0;
            }
        }
    }
}
