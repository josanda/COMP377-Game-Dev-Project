﻿using UnityEngine;

public class playerBoundryAndCamera : MonoBehaviour
{
    private Vector3 StopLocation;    //Used to remember where the player stopped, when the player goes backwards in game
    public GameObject rearBoundry;   //a boundary to prevent the player from going too far back
    private Vector3 boundryOffset = new Vector3(-15,0,0); 
    private Vector3 offset = new Vector3(2f, 4f, -16f);   // Camera offset
    private Vector3 YAxisTemp;       // temp place holder Vector3 for accessing variables within transform.position of a gvien object

    void Start() {
        StopLocation = transform.position;      // set initial location for camera and rearbondary to follow
        Camera.main.transform.position = transform.position + offset;  
    }
    
    void LateUpdate(){

        YAxisTemp = Camera.main.transform.position;  // making the Camera's Y axis mimics player's Y axis
        YAxisTemp.y = transform.position.y + offset.y;
        Camera.main.transform.position = YAxisTemp;

        YAxisTemp = rearBoundry.transform.position;  // making the rearBoundry's Y axis mimics player's Y axis
        YAxisTemp.y = transform.position.y;
        rearBoundry.transform.position = YAxisTemp;

        if( transform.position.x > StopLocation.x) {             // only if player is moving forward and
            StopLocation = transform.position;                         // the player is past the current stop location, update it,
            Camera.main.transform.position = transform.position + offset;     // update camera position, and update rearBoundary Position
            rearBoundry.transform.position = StopLocation + boundryOffset;           
        }        
    }
}
