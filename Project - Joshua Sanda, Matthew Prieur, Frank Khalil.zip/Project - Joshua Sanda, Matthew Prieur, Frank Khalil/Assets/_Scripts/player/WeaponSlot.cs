﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class WeaponSlot : MonoBehaviour{

    public TMP_Text ammoText;
    public TMP_Text weaponSelectedText;
    private GameObject chosenWeapon;
    public int selectedWeapon = 0;
    bool[] isUsable = { true, true, false, false, false };

    void Start(){
        equipWeapon();
    }

    private void Update() {
        int prevWep = selectedWeapon;
        
        if(Input.GetAxis("Mouse ScrollWheel") > 0f) {
            if(selectedWeapon >= transform.childCount - 1)
                selectedWeapon = 0;
            else
                selectedWeapon++;

        }
        if(Input.GetAxis("Mouse ScrollWheel") < 0f) {
            if(selectedWeapon <= 0)
                selectedWeapon = transform.childCount-1;
            else
                selectedWeapon--;

        }
        if(prevWep != selectedWeapon)
            equipWeapon();

        if(Input.GetKey(KeyCode.Alpha1)) {
            selectedWeapon = 0;
            equipWeapon();
        }
        if(Input.GetKey(KeyCode.Alpha2)) {
            selectedWeapon = 1;
            equipWeapon();
        }
        if(Input.GetKey(KeyCode.Alpha3)) {  // Implement later

        }
        if(Input.GetKey(KeyCode.Alpha4)) {

        }
        if(Input.GetKey(KeyCode.Alpha5)) {

        }
        ammoText.text = "Ammo: " + chosenWeapon.GetComponent<Weapon>().MagAmmo.ToString() + "/" + chosenWeapon.GetComponent<Weapon>().TotalAmmo.ToString();
        weaponSelectedText.text = "Weapon: " + chosenWeapon.name;
    }

    public void equipWeapon() {
        int i = 0;
        foreach(Transform t in transform) {
            if(i == selectedWeapon && isUsable[i]) {
                t.gameObject.SetActive(true);
                chosenWeapon = t.gameObject;
            }
            else
                t.gameObject.SetActive(false);
            i++;
        }
    }
}
