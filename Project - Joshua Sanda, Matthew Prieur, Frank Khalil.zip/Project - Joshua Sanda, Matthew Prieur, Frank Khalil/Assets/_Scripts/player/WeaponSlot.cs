﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponSlot : MonoBehaviour
{
    public GameObject weapon;

    void Start()
    {
        weapon.transform.parent= transform;
        weapon.transform.position = transform.position;
    }
}
