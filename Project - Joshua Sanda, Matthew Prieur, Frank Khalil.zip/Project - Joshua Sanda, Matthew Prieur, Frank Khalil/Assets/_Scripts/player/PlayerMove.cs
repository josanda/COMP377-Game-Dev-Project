﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour{

    private Vector3 moveDirection;
    private CharacterController controller;
    private float moveSpeed = 25f;
    private float jumpForce = 30f;
    private float gravityScale = 0.25f;
    private int numOfJumps = 1;
    // Start is called before the first frame update
    void Start()
    {
        controller = GetComponent<CharacterController>();
    }

    // Update is called once per frame
    void Update()
    {
        moveDirection = new Vector3(Input.GetAxis("Horizontal") * moveSpeed, moveDirection.y, 0f);
        if(numOfJumps > 0 && Input.GetButtonDown("Jump")){
            moveDirection.y = jumpForce;
            numOfJumps -= 1;

        }
        if(controller.isGrounded) {
            numOfJumps = 1;
        }
        else { 
            moveDirection.y += (gravityScale * Physics.gravity.y); //only apply gravity when off the ground
        }


        controller.Move(moveDirection*Time.deltaTime);
    }
}
